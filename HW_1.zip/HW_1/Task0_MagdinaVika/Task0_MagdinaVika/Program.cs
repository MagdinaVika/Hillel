﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task0_MagdinaVika
{
    class Program
    {
        static void Main(string[] args)
        //Написать программу для отображения Ваших данных – ФИО, сколько лет и т.д. ​(Обязательно каждые данные отображать через переменные)
        {
            string name = "Magdina Victoria";
            string age = "35";
            string job = "office manager";
            Console.WriteLine("Name: " +name);
            Console.WriteLine("age: "+age);
            Console.WriteLine("job: " +job);
            Console.ReadKey();
        }
    }
}
