﻿using System;


namespace numbers7_15_100_MagdinaVika
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 7, b = 15, c = 100;
            string i = a+"  " + b+"  " + c +"  ";
            Console.WriteLine(i);
            Console.ReadLine();


        }
    }
}
