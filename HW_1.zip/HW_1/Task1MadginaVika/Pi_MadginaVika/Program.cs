﻿using System;

namespace Pi_MadginaVika
{
    class Program
    {
        static void Main(string[] args)
        {
            var pi = 3.14;

                Console.WriteLine(pi);
                Console.ReadLine();
            }
    }
}
